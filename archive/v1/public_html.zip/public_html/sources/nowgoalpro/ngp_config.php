<?php
    const NGP_BASE_URL = 'http://www.nowgoal.pro';
?>