<?php

const DB_SERVER = '127.0.0.1:3306';
const DB_NAME = 'u421817030_soccer';
const DB_USER = 'u421817030_taa';
const DB_PASSWORD = 'jjobva2307';

const DB_SERVER_DEV = '127.0.0.1:3306';
const DB_NAME_DEV = 'livescores';
const DB_USER_DEV = 'root';
const DB_PASSWORD_DEV = '';

?>