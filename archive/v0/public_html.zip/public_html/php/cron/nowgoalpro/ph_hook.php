<?php
declare(strict_types=1);

require_once __DIR__ . '/../../logs.php';
require_once __DIR__ . '/nowgoalpro.php';

$runData = file_get_contents('php://input');

updateParsehubLog("ParseHub webhook newgoalpro", "Start");

if (empty($runData)) {
    updateParsehubLog("ParseHub webhook newgoalpro", "Empty run data");
    die();
}

$runData = urldecode($runData);
$runData = explode("&", $runData);

updateParsehubLog("ParseHub webhook newgoalpro", json_encode($runData));

$ok = in_array("data_ready=1", $runData) && in_array("status=complete", $runData);

if (!$ok) {
    updateParsehubLog("ParseHub webhook newgoalpro", 'Data not ready or Status is not "complete"');
    die();
}

updateParsehubLog("ParseHub webhook newgoalpro", 'Run data ready');

$run = [];
foreach ($runData as $line) {
    $line = trim($line);
    if (strpos($line, "run_token=") === 0) {
        $run['token'] = trim(str_replace("run_token=", "", $line));
    } else if (strpos($line, "start_running_time=") === 0) {
        $run['start_time'] = trim(str_replace("start_running_time=", "", $line));
    }
}

$ok = !empty( $run['token']) && !empty( $run['start_time']);

if (!$ok) {
    updateParsehubLog("ParseHub webhook newgoalpro", 'Could not find run token or start time');
    die();
}

$ph = new ParseHub(PH_PROJECT_TOKEN, PH_API_KEY);

if (!in_array("is_empty=False", $runData)) {
    updateParsehubLog("ParseHub webhook newgoalpro", 'Empty run result - delete run');
    $res = $ph->deleteParseHubRun($run['token']);
    die();
}

updateParsehubLog("ParseHub webhook newgoalpro", "Start getting game data");

$gameData = $ph->getData($run['token']);

if (empty($gameData)) {
    updateParsehubLog("ParseHub webhook newgoalpro", 'No data from Parse Hub');    
    die();
}

updateParsehubLog("ParseHub webhook newgoalpro", "Received game data");

$ngp = new NowGoalPro();
$games = $ngp->parseGameData($gameData);

if (empty($games)) {
    updateParsehubLog("ParseHub webhook newgoalpro", 'No games found');    
    die();
}

$result = file_put_contents(DATA_FILE, json_encode($games));

updateParsehubLog("ParseHub webhook", "Received " . count($games) . " games");

die();

/*

//2019-11-09T17:55:03
$anchorTime = DateTime::createFromFormat('Y-m-d\TH:i:s', $run['start_time'])->getTimestamp();

$games = getParseHubData($run['token']);

$result = file_put_contents(DATA_FILE, json_encode($games));
$dbResult = humanizeBool(saveGamesToDB($games, $anchorTime));

updateParsehubLog("ParseHub webhook save", "db: $dbResult, file: $result" );

*/
/*
curl -X POST "https://scoreslive.000webhostapp.com/php/parsehub_webhook.php" -H "Content-Type: application/x-www-form-urlencoded" -d '{"some":"json"}'
*/

?>