<?php
    const PH_PROJECT_TOKEN = "tW4eVr0vCTQG";
    const PH_API_KEY = "tbXb7zgCH0L8";
?>