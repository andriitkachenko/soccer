<?php
declare(strict_types=1);

require_once __DIR__ . '/../../logs.php';
require_once __DIR__ . '/../../parsehub/parsehub.php';
require_once __DIR__ . '/nowgoalpro_parsehub_config.php';

interface iNowGoalPro {
    public function isParseHubClient() : bool;
    public function runCron1();
    public function runParseHubProject();
    public function parseGameData($phData);
}

class NowGoalPro implements iNowGoalPro {
    
    public function isParseHubClient() : bool {
        return true;
    }

    public function runCron1() {
        // read live games from DB
        // load stats for each live game
        // stop games which are not trackable - at min 20 there is no meaningful stat
        // save events
        // save overall game json
    }
    
    public function runParseHubProject() {
        $ph = new ParseHub(PH_PROJECT_TOKEN, PH_API_KEY);
        $res = $ph->runProject();
        //$ph->logRunProjectResult($res);
        return $res;
    }

    public function parseGameData($phData) {
        if (empty($phData->game) || !is_array($phData->game)) {
            return [];
        }
        $games = [];
        foreach($phData->game as $g) {
            $game = $this->parseGame($g);
            if (!empty($game)) {
                $games[] = $game;
            }
        }
        return $games;
    }

    private function parseGame($g) {
        /*
        {
            "id": "tb_1831305",
            "html": "<div id=\"tb_1831305\" onclick=\"toAnalys(1831305)\" class=\"item \" data-mlid=\"15\">\n        <div class=\"dayrow\" data-day=\"2020_6_19\">July 19. Sunday</div>\n        <div class=\"team \">\n            <div class=\"status\">\n                \n                <span class=\"time\" id=\"mt_1831305\">10:00</span>\n                <span href=\"/football/korea-league/league-15/\" class=\"gameName leaRow\" style=\"color:#990099\">KOR D1</span>\n            </div>\n            <div id=\"rht_1831305\" class=\"homeTeam\">\n                <span id=\"ht_1831305\" class=\"name\">\n                    \n                    Suwon Samsung Bluewings\n                    <i>[9]</i>\n                    <i id=\"hR_1831305\" class=\"redCard\"></i>\n                    <i id=\"hY_1831305\" class=\"yellowCard\"><i>1</i></i>\n                </span>\n            </div>\n            <div class=\"guestTeam\">\n                <span id=\"gt_1831305\" class=\"name\">\n                    \n                    Seongnam FC\n                    <i>[10]</i>\n                    <i id=\"gR_1831305\" class=\"redCard\"></i>\n                    <i id=\"gY_1831305\" class=\"yellowCard\"><i>1</i></i>\n                </span>\n            </div>\n        </div>\n        <div class=\"score\" id=\"stat_1831305\">\n            <i id=\"state_1831305\">\n                87<i class=\"mit\"><img src=\"/images/com/in.gif\"></i>\n            </i>\n            <span class=\"homeS\" id=\"hsc_1831305\">0</span>\n            <span class=\"guestS\" id=\"gsc_1831305\">1</span>\n        </div>\n        <div class=\"odds\">\n            <i>\n                <div id=\"hts_1831305\" class=\"HtScore\">\n                    HT 0-0\n                </div>\n                <div class=\"corner\">\n                    <i id=\"cn_1831305\" class=\"\"></i>\n                    <span id=\"corner_1831305\">3-4</span>\n                </div>\n                <div id=\"tImg_1831305\" class=\"setTop \" onclick=\"MarkTop(1831305,event,1)\"></div>\n            </i>\n            <div class=\"hOdds\">\n                <span id=\"o1_1831305\">0.70</span>\n                <span id=\"o2_1831305\">0</span>\n                <span id=\"o3_1831305\">1.21</span>\n            </div>\n            <div class=\"hOdds\">\n                <span id=\"o4_1831305\">2.00</span>\n                <span id=\"o5_1831305\">1.5</span>\n                <span id=\"o6_1831305\">0.38</span>\n            </div>\n        </div>\n        <br style=\"clear:both;\">\n        <div id=\"exList_1831305\" class=\"exbar\" style=\"display:none\">\n            \n        </div>\n    </div>"
        }
        */
updateParsehubLog("ParseHub webhook newgoalpro", $g->id);        
        if (empty($g->id) || empty($g->html)) {
            return false;
        }
        $id = str_replace('tb_', '', $g->id);
        $game = $this->parseGameHtml($g->html);
        return $game;
        
    }

    private function parseGameHtml($html) {
        $g = [];
        $doc = new DOMDocument();
        $ok = @$doc->loadHTML($html);
        if (!$ok) {
            return false;
        }
        $xpath = new DOMXpath($doc);
        // only item class
        //<div id=\"tb_1831305\" onclick=\"toAnalys(1831305)\" class=\"item \" data-mlid=\"15\">
        $nodes = $xpath->query("//div[contains(@class, 'item')]");
        if ($nodes->count() < 1) {
            return false;
        }
        $class = $nodes->item(0)->attributes->getNamedItem("class")->textContent;
        if (trim($class) != 'item') {
            return false;
        }
        $id = $nodes->item(0)->attributes->getNamedItem("id")->textContent;
        $id = str_replace('tb_', '', trim($id));
        if (empty($id) || !ctype_digit($id)) {
            return false;
        }
        $g['id'] = @intval($id);
        // <div class="dayrow" data-day="2020_6_19">July 19. Sunday</div>
        $nodes = $xpath->query("//div[@data-day]");
        if ($nodes->count() < 1) {
            return false;
        }
        $g['date'] = trim($nodes->item(0)->attributes->getNamedItem("data-day")->textContent);
        /// <span class="time" id="mt_1831305">10:00</span>
        $nodes = $xpath->query("//span[@class='time'][@id='mt_$id']");
        if ($nodes->count() < 1) {
            return false;
        }
        $g['time'] = trim($nodes->item(0)->textContent);
        //<span href="/football/korea-league/league-15/" class="gameName leaRow" style="color:#990099">KOR D1</span>
        $nodes = $xpath->query("//span[contains(@class, 'gameName')][contains(@class, 'leaRow')]");
        if ($nodes->count() < 1) {
            return false;
        }
        $g['league_short'] = trim($nodes->item(0)->textContent);
        $g['league_href'] = trim($nodes->item(0)->attributes->getNamedItem('href')->textContent);
        //<span id="ht_1831305" class="name">
        //     Suwon Samsung Bluewings
        //     <i>[9]</i>
        //     <i id="hR_1831305" class="redCard"></i>
        //     <i id="hY_1831305" class="yellowCard"><i>1</i></i>
        // </span>
        $tid = "ht_$id";
        $nodes = $xpath->query("//span[@id='$tid']/i[1]");
        if ($nodes->count() < 1) {
            return false;
        }
        $g['host_rank'] = trim($nodes->item(0)->textContent);
        $nodes = $xpath->query("//span[@id='$tid']/i");
        foreach($nodes as $ch) {
            $ch->parentNode->removeChild($ch);
        }
        $nodes = $xpath->query("//span[@id='$tid']");
        if ($nodes->count() < 1) {
            return false;
        }
        $g['host'] = trim($nodes->item(0)->textContent);
        
        $tid = "gt_$id";
        $nodes = $xpath->query("//span[@id='$tid']/i[1]");
        if ($nodes->count() < 1) {
            return false;
        }
        $g['guest_rank'] = trim($nodes->item(0)->textContent);
        $nodes = $xpath->query("//span[@id='$tid']/i");
        foreach($nodes as $ch) {
            $ch->parentNode->removeChild($ch);
        }
        $nodes = $xpath->query("//span[@id='$tid']");
        if ($nodes->count() < 1) {
            return false;
        }
        $g['guest'] = trim($nodes->item(0)->textContent);
        return $g;
    }
}
/*
$v = new NowGoalPro();
$g = "<div id=\"tb_1831305\" onclick=\"toAnalys(1831305)\" class=\"item \" data-mlid=\"15\">\n        <div class=\"dayrow\" data-day=\"2020_6_19\">July 19. Sunday</div>\n        <div class=\"team \">\n            <div class=\"status\">\n                \n                <span class=\"time\" id=\"mt_1831305\">10:00</span>\n                <span href=\"/football/korea-league/league-15/\" class=\"gameName leaRow\" style=\"color:#990099\">KOR D1</span>\n            </div>\n            <div id=\"rht_1831305\" class=\"homeTeam\">\n                <span id=\"ht_1831305\" class=\"name\">\n                    \n                    Suwon Samsung Bluewings\n                    <i>[9]</i>\n                    <i id=\"hR_1831305\" class=\"redCard\"></i>\n                    <i id=\"hY_1831305\" class=\"yellowCard\"><i>1</i></i>\n                </span>\n            </div>\n            <div class=\"guestTeam\">\n                <span id=\"gt_1831305\" class=\"name\">\n                    \n                    Seongnam FC\n                    <i>[10]</i>\n                    <i id=\"gR_1831305\" class=\"redCard\"></i>\n                    <i id=\"gY_1831305\" class=\"yellowCard\"><i>1</i></i>\n                </span>\n            </div>\n        </div>\n        <div class=\"score\" id=\"stat_1831305\">\n            <i id=\"state_1831305\">\n                87<i class=\"mit\"><img src=\"/images/com/in.gif\"></i>\n            </i>\n            <span class=\"homeS\" id=\"hsc_1831305\">0</span>\n            <span class=\"guestS\" id=\"gsc_1831305\">1</span>\n        </div>\n        <div class=\"odds\">\n            <i>\n                <div id=\"hts_1831305\" class=\"HtScore\">\n                    HT 0-0\n                </div>\n                <div class=\"corner\">\n                    <i id=\"cn_1831305\" class=\"\"></i>\n                    <span id=\"corner_1831305\">3-4</span>\n                </div>\n                <div id=\"tImg_1831305\" class=\"setTop \" onclick=\"MarkTop(1831305,event,1)\"></div>\n            </i>\n            <div class=\"hOdds\">\n                <span id=\"o1_1831305\">0.70</span>\n                <span id=\"o2_1831305\">0</span>\n                <span id=\"o3_1831305\">1.21</span>\n            </div>\n            <div class=\"hOdds\">\n                <span id=\"o4_1831305\">2.00</span>\n                <span id=\"o5_1831305\">1.5</span>\n                <span id=\"o6_1831305\">0.38</span>\n            </div>\n        </div>\n        <br style=\"clear:both;\">\n        <div id=\"exList_1831305\" class=\"exbar\" style=\"display:none\">\n            \n        </div>\n    </div>";
print_r($v->parseGameHtml($g));
print_r($g);
*/
?>