<?php

/*
	/usr/bin/php /home/u421817030/public_html/php/cron/cron.php
*/

    const CRON_ENABLED = false;
?>